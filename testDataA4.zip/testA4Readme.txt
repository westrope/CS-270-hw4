Note the tests may run for as long as 10 seconds because some of these
tests such as:

Max capacity of jugs: [ 3, 10 ] 
Initial water in jugs: [ 0, 0 ] 
Required volume of water: 8

take a while to find the correct pouring.   Try to be efficient.   For me the whole
test set runs in about three and half seconds on my old laptop.   I may run fewer tests
on the test machine.

