echo "===================="
echo 'getcol 1 2 1 4  < testA4-1.txt '
echo
  getcol 1 2 1 4  < testA4-1.txt 
echo "===================="
echo 'getcol 1:5  < testA4-1.txt '
echo
  getcol 1:5  < testA4-1.txt 
echo "===================="
echo 'getcol 1:7:2 2:7:2 < testA4-1.txt '
echo
  getcol 1:7:2 2:7:2 < testA4-1.txt 
echo "===================="
echo 'getcol 1 2 10 < testA4-1.txt '
echo
  getcol 1 2 10 < testA4-1.txt 
echo "===================="
echo 'getcol -i,  1:10  < testA4-2.txt '
echo
  getcol -i,  1:10  < testA4-2.txt 
echo "===================="
echo 'getcol -i, -s  1:10  < testA4-2.txt '
echo
  getcol -i, -s  1:10  < testA4-2.txt 
echo "===================="
echo 'getcol -i, -o:: 1:10  < testA4-2.txt '
echo
  getcol -i, -o:: 1:10  < testA4-2.txt 
echo "===================="
echo "getcol -i, -s -o'; ' 1:10  < testA4-2.txt "
echo
  getcol -i, -s -o'; ' 1:10  < testA4-2.txt 
echo "===================="
echo "getcol -i, -s -o'; ' -l';' 1:10  < testA4-2.txt"
echo
  getcol -i, -s -o'; ' -l';' 1:10  < testA4-2.txt 
echo "===================="
echo "getcol -i')(' 2 4 < testA4-3.txt"
echo
  getcol -i')(' 2 4 < testA4-3.txt 
echo "===================="
echo "getcol 10:1:-1 < testA4-1.txt"
echo
  getcol 10:1:-1 < testA4-1.txt
echo "===================="
echo "getcol 1 2:1 1 2:2 1 < testA4-1.txt"
echo
  getcol 1 2:1 1 2:2 1 < testA4-1.txt
echo "===================="
